CREATE FUNCTION pg_sleep_until(timestamp with time zone)
  RETURNS void
STRICT
PARALLEL SAFE
COST 1
LANGUAGE SQL
AS $$
select pg_catalog.pg_sleep(extract(epoch from $1) operator(pg_catalog.-) extract(epoch from pg_catalog.clock_timestamp()))
$$;

